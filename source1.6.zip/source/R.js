"use strict";
// jStat 資料請參考 -- http://jstat.github.io/test.html
// 函數預設值的寫法 -- 請參考 http://stackoverflow.com/questions/894860/set-a-default-parameter-value-for-a-javascript-function

U.use("../js/jstat.js", "jStat");

// R = {};
var R = U.global(); 

if (typeof module!=="undefined") module.exports = R;

R.log = function() { 
  var args = Array.prototype.slice.call(arguments)
  console.log.apply(console, args); 
}

R.def=function(arg, value) {
   return (typeof arg === 'undefined' ? value : arg);
}

R.opt = function(options, name, value) {
  if (typeof(options)==='undefined') return value;
  return R.def(options[name], value);
//  return (typeof(options[name]) == 'undefined')?value:options[name];
}

R.fx = function() {
  var args = Array.prototype.slice.call(arguments);
  var f = args[0];
  var fargs = args.slice(1, arguments.length);
  return function(x) {
    return f.apply(null, [x].concat(fargs));
  };
}

R.precision = 4;
R.largeArray = 50;

R.str = function prettyPrint(x) {
    function fmtnum(x) {
        if(x === 0) { return '0'; }
        if(isNaN(x)) { return 'NaN'; }
        if(x<0) { return '-'+fmtnum(-x); }
        if(isFinite(x)) {
            var scale = Math.floor(Math.log(x) / Math.log(10));
            var normalized = x / Math.pow(10,scale);
            var basic = normalized.toPrecision(R.precision);
            if(parseFloat(basic) === 10) { scale++; normalized = 1; basic = normalized.toPrecision(R.precision); }
            return parseFloat(basic).toString()+'e'+scale.toString();
        }
        return 'Infinity';
    }
    var ret = [];
    function foo(x) {
        var k;
        if(typeof x === "undefined") { ret.push(Array(R.precision+8).join(' ')); return false; }
        if(typeof x === "string") { ret.push('"'+x+'"'); return false; }
        if(typeof x === "boolean") { ret.push(x.toString()); return false; }
        if(typeof x === "number") {
            var a = fmtnum(x);
            var b = x.toPrecision(R.precision);
            var c = parseFloat(x.toString()).toString();
            var d = [a,b,c,parseFloat(b).toString(),parseFloat(c).toString()];
            for(k=1;k<d.length;k++) { if(d[k].length < a.length) a = d[k]; }
            ret.push(Array(R.precision+8-a.length).join(' ')+a);
            return false;
        }
        if(x === null) { ret.push("null"); return false; }
        if(typeof x === "function") { 
            ret.push(x.toString());
            var flag = false;
            for(k in x) { if(x.hasOwnProperty(k)) { 
                if(flag) ret.push(',\n');
                else ret.push('\n{');
                flag = true; 
                ret.push(k); 
                ret.push(': \n'); 
                foo(x[k]); 
            } }
            if(flag) ret.push('}\n');
            return true;
        }
        if(x instanceof Array) {
            if(x.length > R.largeArray) { ret.push('...Large Array...'); return true; }
            var flag = false;
            ret.push('[');
            for(k=0;k<x.length;k++) { if(k>0) { ret.push(','); if(flag) ret.push('\n '); } flag = foo(x[k]); }
            ret.push(']');
            return true;
        }
        ret.push('{');
        var flag = false;
        for(k in x) { if(x.hasOwnProperty(k)) { if(flag) ret.push(',\n'); flag = true; ret.push(k); ret.push(': \n'); foo(x[k]); } }
        ret.push('}');
        return true;
    }
    foo(x);
    return ret.join('');
}

// Array.prototype.toString = function() { return R.str(this); } // 有問題，會有邊際效應， c3.js 畫圖時線路不會出現，只會出現點而已。

// ------------------------ 陣列數值函數 ------------------------------
// max(a0..an)
R.max=function(a) {
  var r=Number.MIN_VALUE;
  for (var i in a)
    if (a[i]>r) r=a[i];
  return r;
}

// min(a0..an)
R.min=function(a) {
  var r=Number.MAX_VALUE;
  for (var i in a) 
    if (a[i]<r) r=a[i];
  return r;
}

// a0+a1....+an
R.sum=function(a) {
  var s=0;
  for (var i in a) s+=a[i];
  return s;
}

R.mean=function(a) { return R.sum(a)/a.length; }

R.sd=function(a, flag) { 
  var s = 0;
  var mean = R.mean(a);
  for (var i in a)
    s += Math.pow(a[i]-mean, 2);
  return Math.sqrt(s/(a.length-flag)); 
}

// a0*a1*....an
R.prod=function(a) {
  var p=0;
  for (var i in a) p*=a[i];
  return p;
}

// list(from, from+step, ..., to)
R.steps=function(from, to, step) {
  step = R.def(step, 1);
  var a=[];
  for (var i=0; from+i*step<=to; i++)
    a.push(from+i*step);
  return a;
}
// R.s = R.steps;

// [ o, o, ...., o ]
R.repeats=function(o, n) {
  var a=[];
  for (var i=0; i<n; i++)
    a.push(o);
  return a;
}

// a[1..n]+b[1..n]
R.add=function(a,b) {
  var ab=[];
  for (var i in a) ab.push(a[i]+b[i]);
  return ab;
}

// a[1..n]+b[1..n]
R.sub=function(a,b) {
  var ab=[];
  for (var i in a) ab.push(a[i]-b[i]);
  return ab;
}

R.dot=function(a,b) {
  var s = 0;
  for (var i in a) 
    s += a[i]*b[i];
  return s;
}

R.mul=function(c,a) {
  var ca = [];
  for (var i in a) 
    ca.push(c*a[i]);
  return ca;
}

// a[1..m][1..n] => r[1..m*n]
R.flat=function(a) {
  var r=[];
  for (var i in a)
    for (var j in a[i])
      R.push(a[i][j]);
  return r;
}

R.normalize = function(a) {
  var total = R.sum(a);
  return R.apply(a, function(x) { return x/total; });
}

// apply(a, f)=>[f(a[0]), ..., f(a[n],p)]
R.apply=function() {
  var args = Array.prototype.slice.call(arguments);
  var a = args[0];
  var f = args[1];
  var params = args.slice(2, args.length);
  var fa=[];
  for (var i in a)
    fa.push(f.apply(null, [a[i]].concat(params)));
  return fa;
}

// calls(n, f, p1, p2, ..)
R.calls=function() {
  var args = Array.prototype.slice.call(arguments);
  var n = args[0];
  var f = args[1];
  var params = args.slice(2, args.length);
  var a=[];
  for (var i=0; i<n; i++)
    a.push(f.apply(null, params));
  return a;	
}

// --------------------- 數學函數 ------------------------------
// 標準差
R.sd = function(a, flag) { 
  flag = R.def(flag, 1);
  return jStat.stdev(a, flag); 
}
// 協方差
R.cov = function(x, y) { return jStat.stdev(x, y); }
// 相關係數
R.cor = function(x, y) { return jStat.corrcoeff(x, y); }
// 階層 n!
R.factorial = function(n) { return jStat.factorial(n); }
// log(n!)
R.lfactorial = function(n) { return jStat.factorialln(n); }
// 組合 C(n,m)
R.choose = function(n,m) { return jStat.combination(n, m); }
// log C(n,m)
R.lchoose = function(n,m) { return jStat.combinationln(n, m); }
// 組合 C(n,m)
R.permutation = function(n,m) { return jStat.permutation(n, m); }
// log C(n,m)
R.lchoose = function(n,m) { return jStat.combinationln(n, m); }
// -------------------------- 連續分布 -------------------------------------
// 均等分布
R.runif=function(n, a, b) { return R.calls(n, jStat.uniform.sample, a, b); }
R.dunif=function(x, a, b) { return jStat.uniform.pdf(x, a, b); }
R.punif=function(q, a, b) { return jStat.uniform.cdf(q, a, b); }
R.qunif=function(p, a, b) { return jStat.uniform.inv(p, a, b); }
// 常態分布
R.rnorm=function(n, mean, sd) { return R.calls(n, jStat.normal.sample, mean, sd); }
R.dnorm=function(x, mean, sd) { return jStat.normal.pdf(x, mean, sd); }
R.pnorm=function(q, mean, sd) { return jStat.normal.cdf(q, mean, sd); }
// R.qnorm=function(p, mean, sd) { return R.q2x(p, function (q) { return R.pnorm(q, mean, sd);});}
R.qnorm=function(p, mean, sd) { return jStat.normal.inv(p, mean, sd); }
// 布瓦松分布
R.rpois=function(n, l) { return R.calls(n, jStat.poisson.sample, l); }
R.dpois=function(x, l) { return jStat.poisson.pdf(x, l); }
R.ppois=function(q, l) { return jStat.poisson.cdf(q, l); }
R.qpois=function(p, l) { return jStat.poisson.inv(p, l); }

// F 分布
R.rf=function(n, df1, df2) { return R.calls(n, jStat.centralF.sample, df1, df2); }
R.df=function(x, df1, df2) { return jStat.centralF.sample(x, df1, df2); }
R.pf=function(q, df1, df2) { return jStat.centralF.sample(q, df1, df2); }
R.qf=function(p, df1, df2) { return jStat.centralF.sample(p, df1, df2); }
// T 分布
R.rt=function(n, dof) { return R.calls(n, jStat.studentt.sample, dof); }
R.dt=function(x, dof) { return jStat.studentt.pdf(x, dof); }
R.pt=function(q, dof) { return jStat.studentt.cdf(q, dof); }
R.qt=function(p, dof) { return jStat.studentt.inv(p, dof); }
// Beta 分布
R.rbeta=function(n, alpha, beta) { return R.calls(n, jStat.beta.sample, alpha, beta); }
R.dbeta=function(x, alpha, beta) { return jStat.beta.pdf(x, alpha, beta); }
R.pbeta=function(q, alpha, beta) { return jStat.beta.cdf(q, alpha, beta); }
R.qbeta=function(p, alpha, beta) { return jStat.beta.inv(p, alpha, beta); }
// 柯西分布
R.rcauchy=function(n, local, scale) { return R.calls(n, jStat.cauchy.sample, local, scale); }
R.dcauchy=function(x, local, scale) { return jStat.cauchy.pdf(x, local, scale); }
R.pcauchy=function(q, local, scale) { return jStat.cauchy.cdf(q, local, scale); }
R.qcauchy=function(p, local, scale) { return jStat.cauchy.inv(p, local, scale); }
// chisquare 分布
R.rchisq=function(n, dof) { return R.calls(n, jStat.chisquare.sample, dof); }
R.dchisq=function(x, dof) { return jStat.chisquare.pdf(x, dof); }
R.pchisq=function(q, dof) { return jStat.chisquare.cdf(q, dof); }
R.qchisq=function(p, dof) { return jStat.chisquare.inv(p, dof); }
// 指數分布
R.rexp=function(n, rate) { return R.calls(n, jStat.exponential.sample, rate); }
R.dexp=function(x, rate) { return jStat.exponential.pdf(x, rate); }
R.pexp=function(q, rate) { return jStat.exponential.cdf(q, rate); }
R.qexp=function(p, rate) { return jStat.exponential.inv(p, rate); }
// Gamma 分布
R.rgamma=function(n, shape, scale) { return R.calls(n, jStat.gamma.sample, shape, scale); }
R.dgamma=function(x, shape, scale) { return jStat.gamma.pdf(x, shape, scale); }
R.pgamma=function(q, shape, scale) { return jStat.gamma.cdf(q, shape, scale); }
R.qgamma=function(p, shape, scale) { return jStat.gamma.inv(p, shape, scale); }
// 反 Gamma 分布
R.rinvgamma=function(n, shape, scale) { return R.calls(n, jStat.invgamma.sample, shape, scale); }
R.dinvgamma=function(x, shape, scale) { return jStat.invgamma.pdf(x, shape, scale); }
R.pinvgamma=function(q, shape, scale) { return jStat.invgamma.cdf(q, shape, scale); }
R.qinvgamma=function(p, shape, scale) { return jStat.invgamma.inv(p, shape, scale); }
// 對數常態分布
R.rlognormal=function(n, mu, sigma) { return R.calls(n, jStat.lognormal.sample, mu, sigma); }
R.dlognormal=function(x, mu, sigma) { return jStat.lognormal.pdf(x, mu, sigma); }
R.plognormal=function(q, mu, sigma) { return jStat.lognormal.cdf(q, mu, sigma); }
R.qlognormal=function(p, mu, sigma) { return jStat.lognormal.inv(p, mu, sigma); }
// Pareto 分布
R.rpareto=function(n, scale, shape) { return R.calls(n, jStat.pareto.sample, scale, shape); }
R.dpareto=function(x, scale, shape) { return jStat.pareto.pdf(x, scale, shape); }
R.ppareto=function(q, scale, shape) { return jStat.pareto.cdf(q, scale, shape); }
R.qpareto=function(p, scale, shape) { return jStat.pareto.inv(p, scale, shape); }
// Weibull 分布
R.rweibull=function(n, scale, shape) { return R.calls(n, jStat.weibull.sample, scale, shape); }
R.dweibull=function(x, scale, shape) { return jStat.weibull.pdf(x, scale, shape); }
R.pweibull=function(q, scale, shape) { return jStat.weibull.cdf(q, scale, shape); }
R.qweibull=function(p, scale, shape) { return jStat.weibull.inv(p, scale, shape); }
// 三角分布
R.rtriangular=function(n, a, b, c) { return R.calls(n, jStat.triangular.sample, a, b, c); }
R.dtriangular=function(x, a, b, c) { return jStat.triangular.pdf(x, a, b, c); }
R.ptriangular=function(q, a, b, c) { return jStat.triangular.cdf(q, a, b, c); }
R.qtriangular=function(p, a, b, c) { return jStat.triangular.inv(p, a, b, c); }
// 類似 Beta 分布，但計算更簡單
R.rkumaraswamy=function(n, alpha, beta) { return R.calls(n, jStat.kumaraswamy.sample, alpha, beta); }
R.dkumaraswamy=function(x, alpha, beta) { return jStat.kumaraswamy.pdf(x, alpha, beta); }
R.pkumaraswamy=function(q, alpha, beta) { return jStat.kumaraswamy.cdf(q, alpha, beta); }
R.qkumaraswamy=function(p, alpha, beta) { return jStat.kumaraswamy.inv(p, alpha, beta); }

// -------------------------- 離散分布 -------------------------------------
R.sample1=function(a, p) { 
  var r = Math.random();
  var u = R.repeats(1.0, a.length);
  p = R.def(p, R.normalize(u));
  var psum = 0;
  for (var i in p) {
    psum += p[i];
	if (psum > r)
	  return a[i];
  }
  return null;
}

R.sample=function(n, a, p) { return R.calls(n, R.sample1, a, p); }

// 二項分布
R.rbinom=function(n, N, p) { return R.calls(n, jStat.binomial.sample, N, p); }
R.dbinom=function(x, N, p) { return jStat.binomial.pdf(x, N, p); }
R.pbinom=function(q, N, p) { return jStat.binomial.cdf(q, N, p); }
R.qbinom=function(p, N, q) { return jStat.binomial.inv(p, N, q); }

// 負二項分布
R.rnbinom=function(n, N, p) { return R.calls(n, jStat.negbin.sample, N, p); }
R.dnbinom=function(x, N, p) { return jStat.negbin.pdf(x, N, p); }
R.pnbinom=function(q, N, p) { return jStat.negbin.cdf(q, N, p); }
R.qnbinom=function(p, N, q) { return jStat.negbin.inv(p, N, q); }

// 超幾何分布
R.rhyper=function(n, N, m, k) { return R.calls(n, jStat.hypgeom.sample, N, m, k); }
R.dhyper=function(x, N, m, n) { return jStat.hypgeom.pdf(x, N, m, n); }
R.phyper=function(q, N, m, n) { return jStat.hypgeom.cdf(q, N, m, n); }
R.qhyper=function(p, N, m, n) { return jStat.hypgeom.inv(p, N, m, n); }

// ---------------- 統計與檢定 ----------------------
function opAlt(op) {
  if (op === "=") return "!=";
  if (op === "<") return ">=";
  if (op === ">") return "<=";
  return null;
}

R.test = function(o) { // name, D, x, mu, sd, alpha, op
  var D      = o.D;
  var x      = o.x;
  var alpha  = R.opt(o, "alpha", 0.05);
  o.name     = R.opt(o, "name", "?test");
  o.mu       = R.opt(o, "mu", 0);
  o.sd       = R.opt(o, "sd", R.sd(x));
  o.n        = x.length;
  o.mean     = R.mean(x);
  o.op       = R.opt(o, "op", "=");
  
  var diff, pvalue, interval;
  var q1     = D.o2q(o); // 單尾檢定的 pvalue, //mu, n, mean, sd
  
  if (o.op === "=") {
	pvalue= 2*q1; // 對稱情況：雙尾檢定的 p 值是單尾的兩倍。
    diff  = D.q2p(alpha/2, o);
    interval = [D.q2p(alpha/2, o), D.q2p(1-alpha/2, o)];
  } else {
	if (o.op === "<") {
	  interval = [ D.q2p(alpha, o), Infinity ]; 
	  pvalue = 1-q1;
	}
	if (o.op === ">") {
	  interval=[-Infinity, D.q2p(1-alpha, o)];
	  pvalue = q1;
	}
  }

  return { name: o.name,
		   h0: "mu"+o.op+o.mu, 
		   h1: "mu"+opAlt(o.op)+o.mu,
		   alpha: alpha,
		   op: o.op, 
		   pvalue: pvalue, 
           interval: interval, 
		   mean: o.mean,
		   sd : o.sd,
		   df : D.df(o) };
}

var t = {
  o2q:function(o) {
    var t = (o.mean-o.mu)/(o.sd/Math.sqrt(o.n)); // t=(X-mu)/(sd/sqrt(n))
    return 1-R.pt(Math.abs(t), o.n-1);
  },
  q2p:function(alpha, o) {
    return o.mean + R.qt(alpha, o.n-1) * o.sd / Math.sqrt(o.n);
  },
  df:function(o) { return o.n-1; }
}

var z = {
  o2q:function(o) {
    var z = (o.mean-o.mu)/(o.sd/Math.sqrt(o.n)); // t=(X-mu)/(sd/sqrt(n))
    return 1-R.pnorm(Math.abs(z), 0, 1);
  },
  q2p:function(alpha, o) {
    return o.mean + R.qnorm(alpha, 0, 1) * o.sd / Math.sqrt(o.n);
  },
  df:function(o) { return o.n; }
}

R.ttest = function(x, mu, alpha, op) { 
  return R.test({name:"ttest", D:t, x:x, mu:mu, sd:R.sd(x), alpha:alpha, op:op});
}

R.ztest = function(x, mu, sd, alpha, op) { 
  return R.test({name:"ztest", D:z, x:x, mu:mu, sd:sd, alpha:alpha, op:op});
}

// anovafscore, df1, df2
R.ftest = function(anovafscore, df1, df2) {
  return { 
    h0 : "σ1=σ2", 
	pvalue: jStat.ftest(anovafscore, df1, df2), 
    score: jStat.fscore(anovafscore, df1, df2),
  };
}

R.fixed = function(v) { return v.toFixed(R.precision); }

R.report = function(o) {
    return 	"============"+o.name+" report==========="
			+ "\nH0 	: "+o.h0+"       H1 : "+o.h1
//			+ "\nvalue	: "+R.fixed(o.value)
			+ "\npvalue	: "+R.fixed(o.pvalue)
			+ "\nalpha	: "+o.alpha
			+ "\ninterval: ["+R.fixed(o.interval[0])+","+R.fixed(o.interval[1])+"]"
			+ "\nmean	: "+R.fixed(o.mean)
			+ "\nsd 	: "+R.fixed(o.sd)
			+ "\ndf 	: "+o.df;

}

// anova f-test : array1, array2, array3, ...
R.anovaftest = function() {
  return { 
    h0 : "σ1=σ2=...=σ"+arguments.length, 
	pvalue: jStat.anovaftest(), 
    score: jStat.anovafscore(),
  };
}

// 主成分分析： jStat.PCA(X)

/*
// log n!
R.logp=function(n) { 
  var na = R.steps(1, n, 1);
  var lna= R.apply(na, Math.log);  
  return R.sum(lna);
}

// log n!/k!(n-k)!
R.logc=function(n,k) {
  return R.logp(n)-R.logp(k)-R.logp(n-k);
}
*/
// 將 quantile q 轉為 x
/*
R.q2x=function(q, cdf) {
  var max=10000000, min=-max;
  while (true) {
    var x = (max+min)/2;
	var qx = cdf(x);
    if (Math.abs(qx-q) < 0.00001) 
	  return x;
	else if (q > qx)
	  min = x;
	else
	  max = x;
  }
  return null;
}
*/
/*
// (value, mean, sd, n, sides)
R.tpvalue = function(x, alpha, op) {
  
      tscore = Math.abs(jStat.tscore(args[0], args[1], args[2], args[3]));
      return (args[4] === 1) ?
        (jStat.studentt.cdf(-tscore, args[3]-1)) :
        (jStat.studentt.cdf(-tscore, args[3]-1)*2);

}

R.tci = function(x, alpha, op) {
  var n  = x.length;
  var df = n-1;
  var sd = R.sd(x);
  var m  = R.mean(x);
  if (op === "=") {
    var diff = Math.abs(R.qt(alpha/2, df) * sd / Math.sqrt(n));
    return [m-diff, m+diff];
  } else {
    var diff = Math.abs(R.qt(alpha, df) * sd / Math.sqrt(n));
	if (op === ">") return [-Infinity, m+diff];
	if (op === "<") return [m-diff, Infinity];
  }
  return null;
}
*/
/*
*/
/*
R.mutest = function(name, fp, fq, x, mu, sd, alpha, op, df) {
  alpha  = R.def(alpha, 0.05);
  op     = R.def(op, "=");
  var n  = x.length;
//  var df = n-1;
//  var sd = R.sd(x);
  var m  = R.mean(x);
  var diff, pvalue, interval;
  var v = (m - mu)/(sd/Math.sqrt(n)); // t = (X-mu)/(sd/sqrt(n))
  var pvlt = 1-fp(Math.abs(v), df); // 單尾檢定的 pvalue
  
  if (op === "=") {
	pvalue= 2*pvlt; // 對稱情況：雙尾檢定的 p 值是單尾的兩倍。
    diff  = Math.abs(fq(alpha/2, df) * sd / Math.sqrt(n));
    interval = [m-diff, m+diff];
  } else {
    diff = Math.abs(fq(alpha, df) * sd / Math.sqrt(n));
	if (op === "<") {
	  interval=[m-diff, Infinity];
	  pvalue = 1-pvlt;
	}
	if (op === ">") {
	  interval=[-Infinity, m+diff];
//	  pvalue = fp(-1*Math.abs(v), df);
	  pvalue = pvlt;
	}
  }

  return { name: name,
		   h0: "mu"+op+mu, 
		   h1: "mu"+opAlt(op)+mu,
		   alpha: alpha,
		   op: op, 
		   pvalue: pvalue, 
		   value: v, 
           interval: interval, 
		   mean: m,
		   df : x.length-1 };
}
R.ttest = function(x, mu, alpha, op) { 
  return R.mutest("ttest", R.pt, R.qt, x, mu, R.sd(x), alpha, op, x.length-1);
}

R.pz = function(q) { return R.pnorm(q, 0, 1); }
R.qz = function(p) { return R.qnorm(p, 0, 1); }

R.ztest = function(x, mu, sd, alpha, op) { 
  return R.mutest("ztest", R.pz, R.qz, x, mu, sd, alpha, op, x.length);
}
*/

/*
R.ttest = function(x, mu, alpha, op) {
  alpha  = R.def(alpha, 0.05);
  op     = R.def(op, "=");
  var n  = x.length;
  var df = n-1;
  var sd = R.sd(x);
  var m  = R.mean(x);
  var diff, pvalue, interval;
  var v = (m - mu)/(sd/Math.sqrt(n)); // t = (X-mu)/(sd/sqrt(n))
  var pvlt = 1-R.pt(Math.abs(v), df); // 單尾檢定的 pvalue
  
  if (op === "=") {
	pvalue= 2*pvlt; // 對稱情況：雙尾檢定的 p 值是單尾的兩倍。
    diff  = Math.abs(R.qt(alpha/2, df) * sd / Math.sqrt(n));
    interval = [m-diff, m+diff];
  } else {
    diff = Math.abs(R.qt(alpha, df) * sd / Math.sqrt(n));
	if (op === "<") {
	  interval=[m-diff, Infinity];
	  pvalue = 1-pvlt;
	}
	if (op === ">") {
	  interval=[-Infinity, m+diff];
	  pvalue = R.pt(-1*Math.abs(v), df);
	}
  }

  return { name: "ttest",
		   h0: "mu"+op+mu, 
		   h1: "mu"+opAlt(op)+mu,
		   alpha: alpha,
		   op: op, 
		   pvalue: pvalue, 
		   value: v, 
           interval: interval, 
		   mean: m,
		   df : x.length-1 };
}
*/
// function toSide(op) { return (op==="="?2:1); }

/*
var z = {
  q2x:function(alpha, n, mean, sd) {
    return Math.abs(R.qnorm(alpha, 0, 1) * sd / Math.sqrt(n));
  },
  x2q:function(mu, n, mean, sd) {
    var z = (mean-mu)/(sd/Math.sqrt(n)); // z=(X-mu)/(sd/sqrt(n))
    return 1-R.pnorm(Math.abs(z), 0, 1);
  },
  df:function(n) { return n; }
}
*/